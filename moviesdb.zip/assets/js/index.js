    $(document).ready(function(){
        $("#a_close").click(function(){
          $("#trailer_modal").modal('hide');
        });
        var pages = GetURLParameter('pages');
        if(parseInt(pages) < 1 || !pages){
          $("a[id='a1']").attr("disabled", "");
          $("a[id='a2']").attr("href", "/?pages=2");
        }else{
          $("a[id='a1']").attr("href", "/?pages=" + (parseInt(pages) - parseInt(1)));
          $("a[id='a2']").attr("href", "/?pages=" + (parseInt(pages) + parseInt(1)));
        }
        if(!pages){
          var search = GetURLParameter('search');
          if(!search){
            $.ajax({
                url: "/api.php?menu=pages&id=1",
                //async: false,
                type: "GET",
                dataType: "json",
                success: function(response){
                    $.each(response['data'], function(index, value){
                      $("#rows").append("<div class=\"col-md-4\"><div class=\"card mb-4 box-shadow\"><img class=\"card-img-top\" height=\"300\" src=\" " + value['poster_path'] + " \" alt=\"Card image cap\"><div class=\"card-body\"><p class=\"card-text\"><b>Title :</b> "+ value['title'] +"<br><b>Release Date : </b><i>"+ value['release_date'] +"</i></p><div class=\"d-flex justify-content-between align-items-center\"><div class=\"btn-group\"><button id=\"preview\"type=\"button\" class=\"btn btn-sm btn-outline-secondary\" data-yturl=\""+ value['preview_path']+"\"><i class=\"fa fa-film\"></i> Trailer</button><button id=\"overview\" type=\"button\" class=\"btn btn-sm btn-outline-secondary\" data-overview=\""+ value['overview'] +"\"><i class=\"fa fa-align-justify\"></i> Review</button><button id=\"watch\" type=\"button\" class=\"btn btn-sm btn-outline-secondary\" data-title=\""+ value['title'] +"\" data-url=\""+ value['videos'][0]['link'] +"\"><i class=\"fa fa-eye\"></i> Watch</button></div><small class=\"text-muted\"><b>Vote : </b><i>"+ value['vote_average'] +"/10</i></small></div></div></div></div>");
                      if(index + 1 == 12){
                        return false;
                      }
                    });
                    $("#a_close").click(function(){
                      $("#iframe").remove();
                    });
                    $("button[id='overview']").on("click", function(){
                        $("#exampleModalLabel").empty();
                        $("#modal_body").empty();
                        $("#exampleModalLabel").append("Review");
                        $("#modal_body").append("<p>"+ $(this).data('overview') +"</p>")
                        $("#trailer_modal").modal('show');
                    });
                    $("button[id='preview']").on("click", function(){
                      var link = $(this).data('yturl');
                      if(link == null){
                        alert("Sorry, trailer not found.");
                      }else{
                        $("#exampleModalLabel").empty();
                        $("#modal_body").empty();
                        $("#exampleModalLabel").append("Trailer");
                        $("#modal_body").append('<iframe id="iframe" width="100%" height="400px" frameborder="0" src="'+ link +'" allowfullscreen></iframe>')
                        $("#trailer_modal").modal('show');
                      }
                    });
                    $("button[id='watch']").on("click", function(){
                      var link = $(this).data('url');
                      var title = $(this).data('title');
                      if(link == null){
                        alert("Sorry, embed movie not found.");
                      }else{
                        $("#exampleModalLabel").empty();
                        $("#modal_body").empty();
                        $("#exampleModalLabel").append("Watching: " + title);
                        $("#modal_body").append('<iframe id="iframe" width="100%" height="400px" frameborder="0" src="'+ link +'" allowfullscreen></iframe>');
                        $("#modal_body").append("<hr width='60%' class='text-center'><p class='text-muted text-center'><i>Selamat Menonton!</i></p>");
                        $("#trailer_modal").modal('show');
                      }
                    });
                },
              error: function (jqXHR, exception) {
                      var msg = '';
                      if (jqXHR.status === 0) {
                          msg = 'Not connect.\n Verify Network.';
                      } else if (jqXHR.status == 404) {
                          msg = 'Requested page not found. [404]';
                      } else if (jqXHR.status == 500) {
                          msg = 'Internal Server Error [500].';
                      } else if (exception === 'parsererror') {
                          msg = 'Requested JSON parse failed.';
                      } else if (exception === 'timeout') {
                          msg = 'Time out error.';
                      } else if (exception === 'abort') {
                          msg = 'Ajax request aborted.';
                      } else {
                          msg = 'Uncaught Error.\n' + jqXHR.responseText;
                      }
                      alert(msg);
                  }
            });
          }else{
            $("nav[id='nav_page']").remove();
            $("input[name='search']").attr("value", search.replace(/\+/g, " "));
            $.ajax({
              url: "/api.php?menu=search&query=" + search.toString(),
              //async: false,
              type: "GET",
              dataType: "json",
              success: function(response){
                  if(!response['movies'][0]){
                    $("#rows").empty();
                    $("#rows").append('<center><h4> '+ search.replace(/\+/g, " ") +' cannot be found.</h4></center>');
                  }else{
                    $("#rows").empty();
                    $.each(response['movies'], function(index, value){
                      $("#rows").append("<div class=\"col-md-4\"><div class=\"card mb-4 box-shadow\"><img class=\"card-img-top\" height=\"300\" src=\" " + value['poster_path'] + " \" alt=\"Card image cap\"><div class=\"card-body\"><p class=\"card-text\"><b>Title :</b> "+ value['title'] +"<br><b>Release Date : </b><i>"+ value['release_date'] +"</i></p><div class=\"d-flex justify-content-between align-items-center\"><div class=\"btn-group\"><button id=\"preview\"type=\"button\" class=\"btn btn-sm btn-outline-secondary\" data-yturl=\""+ value['preview_path']+"\"><i class=\"fa fa-film\"></i> Trailer</button><button id=\"overview\" type=\"button\" class=\"btn btn-sm btn-outline-secondary\" data-overview=\""+ value['overview'] +"\"><i class=\"fa fa-align-justify\"></i> Review</button><button id=\"watch\" type=\"button\" class=\"btn btn-sm btn-outline-secondary\" data-title=\""+ value['title'] +"\" data-url=\""+ value['videos'][0]['link'] +"\"><i class=\"fa fa-eye\"></i> Watch</button></div><small class=\"text-muted\"><b>Vote : </b><i>"+ value['vote_average'] +"/10</i></small></div></div></div></div>");
                      if(index + 1 == 12){
                        return false;
                      }
                    });
                  }
                  $("#a_close").click(function(){
                    $("#iframe").remove();
                  });
                  $("button[id='overview']").on("click", function(){
                      $("#exampleModalLabel").empty();
                      $("#modal_body").empty();
                      $("#exampleModalLabel").append("Review");
                      $("#modal_body").append("<p>"+ $(this).data('overview') +"</p>")
                      $("#trailer_modal").modal('show');
                  });
                  $("button[id='preview']").on("click", function(){
                    var link = $(this).data('yturl');
                    if(link == null){
                      alert("Sorry, trailer not found.");
                    }else{
                      $("#exampleModalLabel").empty();
                      $("#modal_body").empty();
                      $("#exampleModalLabel").append("Trailer");
                      $("#modal_body").append('<iframe id="iframe" width="100%" height="400px" frameborder="0" src="'+ link +'" allowfullscreen></iframe>')
                      $("#trailer_modal").modal('show');
                    }
                  });
                  $("button[id='watch']").on("click", function(){
                    var link = $(this).data('url');
                    var title = $(this).data('title');
                    if(link == null){
                      alert("Sorry, embed movie not found.");
                    }else{
                      $("#exampleModalLabel").empty();
                      $("#modal_body").empty();
                      $("#exampleModalLabel").append("Watching: " + title);
                      $("#modal_body").append('<iframe id="iframe" width="100%" height="400px" frameborder="0" src="'+ link +'" allowfullscreen></iframe>');
                      $("#modal_body").append("<hr width='60%' class='text-center'><p class='text-muted text-center'><i>Selamat Menonton!</i></p>");
                      $("#trailer_modal").modal('show');
                    }
                  });
              },
            error: function (jqXHR, exception) {
                    var msg = '';
                    if (jqXHR.status === 0) {
                        msg = 'Not connect.\n Verify Network.';
                    } else if (jqXHR.status == 404) {
                        msg = 'Requested page not found. [404]';
                    } else if (jqXHR.status == 500) {
                        msg = 'Internal Server Error [500].';
                    } else if (exception === 'parsererror') {
                        msg = 'Requested JSON parse failed.';
                    } else if (exception === 'timeout') {
                        msg = 'Time out error.';
                    } else if (exception === 'abort') {
                        msg = 'Ajax request aborted.';
                    } else {
                        msg = 'Uncaught Error.\n' + jqXHR.responseText;
                    }
                    alert(msg);
                }
            });
          }
        }else{
          $.ajax({
              url: "/api.php?menu=pages&id=" + parseInt(pages),
              //async: false,
              type: "GET",
              dataType: "json",
              success: function(response){
                  $.each(response['data'], function(index, value){
                    $("#rows").append("<div class=\"col-md-4\"><div class=\"card mb-4 box-shadow\"><img class=\"card-img-top\" height=\"300\" src=\" " + value['poster_path'] + " \" alt=\"Card image cap\"><div class=\"card-body\"><p class=\"card-text\"><b>Title :</b> "+ value['title'] +"<br><b>Release Date : </b><i>"+ value['release_date'] +"</i></p><div class=\"d-flex justify-content-between align-items-center\"><div class=\"btn-group\"><button id=\"preview\"type=\"button\" class=\"btn btn-sm btn-outline-secondary\" data-yturl=\""+ value['preview_path']+"\"><i class=\"fa fa-film\"></i> Trailer</button><button id=\"overview\" type=\"button\" class=\"btn btn-sm btn-outline-secondary\" data-overview=\""+ value['overview'] +"\"><i class=\"fa fa-align-justify\"></i> Review</button><button id=\"watch\" type=\"button\" class=\"btn btn-sm btn-outline-secondary\" data-title=\""+ value['title'] +"\" data-url=\""+ value['videos'][0]['link'] +"\"><i class=\"fa fa-eye\"></i> Watch</button></div><small class=\"text-muted\"><b>Vote : </b><i>"+ value['vote_average'] +"/10</i></small></div></div></div></div>");
                    if(index + 1 == 12){
                      return false;
                    }
                  });
                  $("#a_close").click(function(){
                    $("#iframe").remove();
                  });
                  $("button[id='overview']").on("click", function(){
                      $("#exampleModalLabel").empty();
                      $("#modal_body").empty();
                      $("#exampleModalLabel").append("Review");
                      $("#modal_body").append("<p>"+ $(this).data('overview') +"</p>")
                      $("#trailer_modal").modal('show');
                  });
                  $("button[id='preview']").on("click", function(){
                    var link = $(this).data('yturl');
                    if(link == null){
                      alert("Sorry, trailer not found.");
                    }else{
                      $("#exampleModalLabel").empty();
                      $("#modal_body").empty();
                      $("#exampleModalLabel").append("Trailer");
                      $("#modal_body").append('<iframe id="iframe" width="100%" height="400px" frameborder="0" src="'+ link +'" allowfullscreen></iframe>')
                      $("#trailer_modal").modal('show');
                    }
                  });
                  $("button[id='watch']").on("click", function(){
                    var link = $(this).data('url');
                    var title = $(this).data('title');
                    if(link == null){
                      alert("Sorry, embed movie not found.");
                    }else{
                      $("#exampleModalLabel").empty();
                      $("#modal_body").empty();
                      $("#exampleModalLabel").append("Watching: " + title);
                      $("#modal_body").append('<iframe id="iframe" width="100%" height="400px" frameborder="0" src="'+ link +'" allowfullscreen></iframe>');
                      $("#modal_body").append("<hr width='60%' class='text-center'><p class='text-muted text-center'><i>Selamat Menonton!</i></p>");
                      $("#trailer_modal").modal('show');
                    }
                  });
              },
            error: function (jqXHR, exception) {
                    var msg = '';
                    if (jqXHR.status === 0) {
                        msg = 'Not connect.\n Verify Network.';
                    } else if (jqXHR.status == 404) {
                        msg = 'Requested page not found. [404]';
                    } else if (jqXHR.status == 500) {
                        msg = 'Internal Server Error [500].';
                    } else if (exception === 'parsererror') {
                        msg = 'Requested JSON parse failed.';
                    } else if (exception === 'timeout') {
                        msg = 'Time out error.';
                    } else if (exception === 'abort') {
                        msg = 'Ajax request aborted.';
                    } else {
                        msg = 'Uncaught Error.\n' + jqXHR.responseText;
                    }
                    alert(msg);
                }
          });
        }
      });
      function GetURLParameter(sParam)
      {
        var sPageURL = window.location.search.substring(1);
        var sURLVariables = sPageURL.split('&');
        for (var i = 0; i < sURLVariables.length; i++)
        {
          var sParameterName = sURLVariables[i].split("=");
          if(sParameterName[0] == sParam)
          {
            return sParameterName[1];
          }
        }
      }