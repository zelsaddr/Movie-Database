<?php
/**
 * @author Mazterin Dev (Izzeldin Addarda)
 * @package Movie Database
 * Change the copyright doesn't make you a real coder.
 */
class Movies21
{
    private $API_URL = "http://167.99.55.121/api/";

    public function search($search_title)
    {
        return $this->cURL($this->API_URL."search/".rawurlencode($search_title))[1];
    }
    public function movie_pages($page = 1)
    {
        return $this->cURL($this->API_URL."movies?page=".$page)[1];
    }
    public function recommended()
    {
        return $this->cURL($this->API_URL."movies/recommended")[1];
    }
    public function recents()
    {
        return $this->cURL($this->API_URL."movies/recents")[1];
    }
    public function popular()
    {
        return $this->cURL($this->API_URL."movies/popular")[1];
    }
    private function cURL($url, $post = 0)
    {
        $headers = array();
        $headers[] = 'User-Agent: Dart/2.5 (dart:io)';
        $headers[] = 'Accept-Encoding: gzip';
        $headers[] = 'Content-Length: 0';
        $headers[] = 'Host: 167.99.55.121';
        $ch = curl_init();
        $options = array(
            CURLOPT_URL     => $url,
            CURLOPT_RETURNTRANSFER  => true,
            CURLOPT_FOLLOWLOCATION  => true,
            CURLOPT_TIMEOUT         => 30,
            CURLOPT_CONNECTTIMEOUT  => 30,
            CURLOPT_SSL_VERIFYPEER  => false,
            CURLOPT_SSL_VERIFYHOST  => false,
            CURLOPT_HTTPHEADER      => $headers,
            CURLOPT_HEADER          => true
        );
        if($post){
            $options[CURLOPT_POST]          = true;
            $options[CURLOPT_POSTFIELDS]    = $post; 
        }
        curl_setopt_array($ch, $options);
        $response = curl_exec($ch);
        $httpcode = curl_getinfo($ch);
        if(!$httpcode) die($this->json_builder(500, "Curl Error : ".curl_error($ch))); else{
            $header = substr($response, 0, curl_getinfo($ch, CURLINFO_HEADER_SIZE));
            $body = substr($response, curl_getinfo($ch, CURLINFO_HEADER_SIZE));
            curl_close($ch);
            return array($header, $body);
        }
    }
    public function json_builder($status = 200, $msg, array $msg_plus = null)
    {
        return json_encode(array(
            "status"    => $status,
            "message"   => $msg,
            "msg_plus"  => is_null($msg_plus) !== FALSE ? $msg_plus : null
        ));
    }
}