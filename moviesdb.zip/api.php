<?php
/**
 * @author Mazterin Dev (Izzeldin Addarda)
 * @package Movie Database
 * Change the copyright doesn't make you a real coder.
 */
require "./classes/movies.class.php";
$Movies21 = new Movies21;
if(isset($_GET['menu'])){
    switch($_GET['menu'])
    {
        case 'popular':
            echo $Movies21->popular();
            break;
        case 'search':
            if(isset($_GET['query'])){
                echo $Movies21->search($_GET['query']);
            }else{
                echo $Movies21->json_builder(500, "ERROR, Parameter query cannot be empty.");
            }
            break;
        case 'recents':
            echo $Movies21->recents();
            break;
        case 'recommended':
            echo $Movies21->recommended();
            break;
        case 'pages':
            if(isset($_GET['id'])){
                echo $Movies21->movie_pages(trim($_GET['id']));
            }else{
                echo $Movies21->json_builder(500, "ERROR, Parameter id cannot be empty.");
            }
            break;
        default:
            echo "<ul>";
            echo "<li><a href='./api.php?menu=popular'>Get Popular Movies </a></li>";
            echo "<li><a href='./api.php?menu=search&query=joker'>Get Movies by Search Query </a></li>";
            echo "<li><a href='./api.php?menu=recommended'>Get Recommended Movies </a></li>";
            echo "<li><a href='./api.php?menu=pages&id=1'>Get Movies by Page ID</a></li>";
            echo "<li><a href='./api.php?menu=recents'>Get Recents Movie </a></li>";
            break;
    }
}else{
    echo $Movies21->json_builder(500, "GET Request no detected, Contact admin first.");
}
?>